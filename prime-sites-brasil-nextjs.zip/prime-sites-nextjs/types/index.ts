export interface NavLink {
  href: string;
  label: string;
}

export interface HeroStat {
  num: string;
  label: string;
}

export interface ProblemaRow {
  icon: string;
  label: string;
  sub: string;
}

export interface PillarItem {
  icon: string;
  title: string;
  text: string;
}

export interface Pillar {
  name: string;
  title: string;
  items: PillarItem[];
}

export interface TimelineStep {
  num: string;
  icon: string;
  title: string;
  text: string;
}

export interface PorQueItem {
  icon: string;
  title: string;
  text: string;
}

export interface PerformanceMetric {
  label: string;
  value: string;
  width: number;
}

export interface PortfolioItem {
  segment: string;
  name: string;
  description?: string;
  tags: string[];
  href: string;
  mockGradient: string;
  accentColor: string;
  barBg: string;
  featured?: boolean;
}

export interface Testimonial {
  quote: string;
  name: string;
  business: string;
  chip: string;
  initials: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface FormFeature {
  icon: string;
  label: string;
}
