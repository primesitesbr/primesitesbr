'use client';

import { ReactNode } from 'react';
import { useReveal } from '@/hooks/useReveal';

type RevealDirection = 'up' | 'from-left' | 'from-right' | 'scale-in';

interface RevealProps {
  children: ReactNode;
  direction?: RevealDirection;
  delay?: 1 | 2 | 3 | 4;
  onDark?: boolean;
  className?: string;
  as?: 'div' | 'section';
}

const directionClass: Record<RevealDirection, string> = {
  up: '',
  'from-left': 'from-left',
  'from-right': 'from-right',
  'scale-in': 'scale-in',
};

/** Wraps any block of content with the site's signature scroll-reveal
 * animation (fade + translate), matching the original .reveal classes. */
export default function Reveal({
  children,
  direction = 'up',
  delay,
  onDark = false,
  className = '',
  as = 'div',
}: RevealProps) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const Tag = as as any;

  const classes = [
    'reveal',
    directionClass[direction],
    delay ? `d${delay}` : '',
    onDark ? 'on-dark' : '',
    visible ? 'visible' : '',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <Tag ref={ref} className={classes}>
      {children}
    </Tag>
  );
}
