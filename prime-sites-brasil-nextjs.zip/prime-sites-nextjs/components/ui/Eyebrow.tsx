import { ReactNode } from 'react';

interface EyebrowProps {
  children: ReactNode;
  gold?: boolean;
  center?: boolean;
}

export default function Eyebrow({ children, gold = false, center = false }: EyebrowProps) {
  return (
    <div
      className={`eyebrow${gold ? ' eyebrow--gold' : ''}`}
      style={center ? { justifyContent: 'center' } : undefined}
    >
      {children}
    </div>
  );
}
