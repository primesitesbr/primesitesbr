import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { portfolioItems } from '@/lib/data';
import { waLink } from '@/lib/constants';
import type { PortfolioItem } from '@/types';

function FeaturedCard({ item }: { item: PortfolioItem }) {
  return (
    <Reveal className="pf-featured">
      <div className="pf-screen" style={{ background: '#0D1829' }}>
        <div className="pf-bar" style={{ background: item.barBg }}>
          <div className="pf-dot" style={{ background: '#FF5F57' }} />
          <div className="pf-dot" style={{ background: '#FEBC2E' }} />
          <div className="pf-dot" style={{ background: '#28C840' }} />
        </div>
        <div className="pf-body">
          <div className="pf-hero-block" style={{ background: item.mockGradient }}>
            <div className="pf-h" />
            <div className="pf-s" />
            <div className="pf-b" style={{ background: 'var(--gold)' }} />
          </div>
          <div className="pf-cards">
            <div className="pf-card" style={{ height: 38, background: item.accentColor }} />
            <div className="pf-card" style={{ height: 38, background: item.accentColor }} />
            <div className="pf-card" style={{ height: 38, background: item.accentColor }} />
          </div>
        </div>
      </div>
      <div className="pf-info">
        <div className="pf-seg">{item.segment}</div>
        <div className="pf-name">{item.name}</div>
        {item.description && <p className="pf-desc">{item.description}</p>}
        <div className="pf-tags">
          {item.tags.map((tag) => (
            <span className="ptag" key={tag}>
              {tag}
            </span>
          ))}
        </div>
        <a
          href={waLink(item.href)}
          className="pf-btn"
          target="_blank"
          rel="noopener noreferrer"
        >
          Ver projeto →
        </a>
      </div>
    </Reveal>
  );
}

function SupportCard({ item, delay }: { item: PortfolioItem; delay: 1 | 2 }) {
  return (
    <Reveal delay={delay}>
      <div
        className="pf-screen"
        style={{
          background: item.barBg,
          borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
          overflow: 'hidden',
        }}
      >
        <div className="pf-bar" style={{ background: item.barBg }}>
          <div className="pf-dot" style={{ background: '#FF5F57' }} />
          <div className="pf-dot" style={{ background: '#FEBC2E' }} />
          <div className="pf-dot" style={{ background: '#28C840' }} />
        </div>
        <div className="pf-body">
          <div className="pf-hero-block" style={{ background: item.mockGradient }}>
            <div className="pf-h" />
            <div className="pf-s" />
            <div className="pf-b" style={{ background: item.accentColor }} />
          </div>
          <div className="pf-cards">
            <div className="pf-card" style={{ height: 32, background: item.accentColor }} />
            <div className="pf-card" style={{ height: 32, background: item.accentColor }} />
            <div className="pf-card" style={{ height: 32, background: item.accentColor }} />
          </div>
        </div>
      </div>
      <div
        className="pf-info"
        style={{
          border: '1px solid var(--line)',
          borderTop: 'none',
          borderRadius: '0 0 var(--radius-lg) var(--radius-lg)',
        }}
      >
        <div className="pf-seg">{item.segment}</div>
        <div className="pf-name">{item.name}</div>
        <div className="pf-tags">
          {item.tags.map((tag) => (
            <span className="ptag" key={tag}>
              {tag}
            </span>
          ))}
        </div>
        <a
          href={waLink(item.href)}
          className="pf-btn"
          target="_blank"
          rel="noopener noreferrer"
        >
          Ver projeto →
        </a>
      </div>
    </Reveal>
  );
}

export default function Portfolio() {
  const [featured, ...support] = portfolioItems;

  return (
    <section className="portfolio" id="portfolio">
      <div className="container">
        <Reveal className="portfolio-header">
          <Eyebrow>Nosso trabalho</Eyebrow>
          <h2 className="section-title">Portfólio</h2>
          <p className="section-sub">Sites reais, negócios reais, resultados reais.</p>
        </Reveal>

        <FeaturedCard item={featured} />

        <div className="pf-support">
          {support.map((item, i) => (
            <SupportCard item={item} delay={(i + 1) as 1 | 2} key={item.name} />
          ))}
        </div>
      </div>
    </section>
  );
}
