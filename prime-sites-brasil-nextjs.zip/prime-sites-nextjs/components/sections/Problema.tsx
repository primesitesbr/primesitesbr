import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { problemaRows } from '@/lib/data';

export default function Problema() {
  return (
    <section className="problema" id="problema">
      <div className="container">
        <Reveal>
          <Eyebrow>Antes de te ligar</Eyebrow>
        </Reveal>
        <Reveal>
          <h2 className="section-title">
            Ele já decidiu. E foi o
            <br />
            Google quem decidiu por ele.
          </h2>
        </Reveal>
        <div className="problema-grid">
          <Reveal className="problema-text">
            <p>
              Mais de 80% das pessoas pesquisam uma empresa on-line antes de entrar em contato.
              Nesse momento, <strong>seu site — ou a falta dele — fala por você</strong> antes
              que você diga qualquer palavra.
            </p>
            <p>
              Se o que aparece é um perfil de Instagram parado, um site antigo ou nada, a
              decisão já foi tomada. E não foi a seu favor.
            </p>
            <div className="problema-stat">
              <div className="ps-num">80%</div>
              <div className="ps-text">
                dos consumidores pesquisam uma empresa on-line antes de comprar ou entrar em
                contato
              </div>
            </div>
          </Reveal>
          <Reveal delay={2} className="problema-list">
            {problemaRows.map((row) => (
              <div className="problema-row" key={row.label}>
                <div className="problema-icon">{row.icon}</div>
                <div>
                  <div className="problema-label">{row.label}</div>
                  <div className="problema-sub">{row.sub}</div>
                </div>
              </div>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
