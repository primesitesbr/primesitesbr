import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { timelineSteps } from '@/lib/data';

const delays = [undefined, 1, 2, 3] as const;

export default function ComoFunciona() {
  return (
    <section className="como-funciona noise" id="como-funciona">
      <div className="container">
        <Reveal onDark className="como-header">
          <Eyebrow gold>Processo simples</Eyebrow>
          <h2 className="section-title">Como funciona</h2>
          <p className="section-sub">Do zero ao site no ar em poucos dias, sem complicação.</p>
        </Reveal>
        <div className="timeline">
          {timelineSteps.map((step, i) => (
            <Reveal onDark delay={delays[i]} className="tl-step" key={step.num}>
              <span className="tl-num">{step.num}</span>
              <div className="tl-dot">{step.icon}</div>
              <div className="tl-title">{step.title}</div>
              <div className="tl-text">{step.text}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
