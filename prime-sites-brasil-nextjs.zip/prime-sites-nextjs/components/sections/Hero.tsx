'use client';

import Link from 'next/link';
import Reveal from '@/components/ui/Reveal';
import CompareSlider from './CompareSlider';
import { useMagnetic } from '@/hooks/useMagnetic';
import { heroStats } from '@/lib/data';
import { waLink } from '@/lib/constants';

export default function Hero() {
  const ctaRef = useMagnetic<HTMLAnchorElement>();

  return (
    <section className="hero" id="top">
      <div className="container">
        <div className="hero-grid">
          <Reveal direction="from-left">
            <div className="hero-badge">
              <div className="hero-badge-dot" />
              Sites no ar em até 7 dias
            </div>
            <h1 className="hero-title">
              Enquanto seu negócio não tem um site, alguém está escolhendo o{' '}
              <em>concorrente</em>.
            </h1>
            <p className="hero-sub">
              A <strong>Prime Sites Brasil</strong> cria o site que estava faltando — pronto,
              rápido e feito para transformar quem visita em quem compra. Arraste o comparativo
              ao lado e veja a diferença.
            </p>
            <div className="hero-actions">
              <a
                ref={ctaRef}
                href={waLink('Olá! Quero solicitar um orçamento.')}
                className="btn-primary"
                data-magnetic
                target="_blank"
                rel="noopener noreferrer"
              >
                💬 Quero meu site
              </a>
              <Link href="#portfolio" className="btn-ghost">
                Ver portfólio →
              </Link>
            </div>
            <div className="hero-stats">
              {heroStats.map((stat) => (
                <div className="hero-stat" key={stat.label}>
                  <div className="hero-stat-num">{stat.num}</div>
                  <div className="hero-stat-label">{stat.label}</div>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal direction="from-right" delay={2}>
            <CompareSlider />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
