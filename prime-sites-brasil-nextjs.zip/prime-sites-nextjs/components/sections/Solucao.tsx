import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { pillars } from '@/lib/data';

export default function Solucao() {
  return (
    <section className="solucao" id="solucao">
      <div className="container">
        <Reveal className="solucao-header">
          <Eyebrow>O que você recebe</Eyebrow>
          <h2 className="section-title">
            Um site completo, sem você
            <br />
            precisar entender de tecnologia
          </h2>
          <p className="section-sub">
            Cada projeto sai pronto para atrair, converter e representar bem o seu negócio —
            sem letras miúdas.
          </p>
        </Reveal>

        {pillars.map((pillar) => (
          <Reveal as="div" className="pillar" key={pillar.name}>
            <div>
              <div className="pillar-name">{pillar.name}</div>
              <div className="pillar-title">{pillar.title}</div>
            </div>
            <div className="pillar-items">
              {pillar.items.map((item) => (
                <div className="pillar-item" key={item.title}>
                  <div className="pillar-icon">{item.icon}</div>
                  <div>
                    <div className="pillar-item-title">{item.title}</div>
                    <div className="pillar-item-text">{item.text}</div>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
