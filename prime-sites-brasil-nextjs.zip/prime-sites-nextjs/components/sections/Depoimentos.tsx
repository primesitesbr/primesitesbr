import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { testimonials } from '@/lib/data';

export default function Depoimentos() {
  return (
    <section className="depoimentos noise">
      <div className="container">
        <Reveal onDark className="depo-header">
          <Eyebrow gold>Quem já confiou</Eyebrow>
          <h2 className="section-title">O que nossos clientes dizem</h2>
        </Reveal>
      </div>
      <div className="container">
        <Reveal onDark className="depo-track">
          {testimonials.map((t) => (
            <div className="depo-slide" key={t.name}>
              <p className="depo-quote">{t.quote}</p>
              <div className="depo-author">
                <div className="depo-avatar">{t.initials}</div>
                <div>
                  <div className="depo-name">{t.name}</div>
                  <div className="depo-biz">{t.business}</div>
                </div>
              </div>
              <span className="depo-chip">{t.chip}</span>
            </div>
          ))}
        </Reveal>
        <p className="depo-hint">← arraste para ver mais →</p>
      </div>
    </section>
  );
}
