'use client';

import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { useReveal } from '@/hooks/useReveal';
import { usePerformanceBars } from '@/hooks/usePerformanceBars';
import { porqueItems, performanceMetrics } from '@/lib/data';

export default function PorQueNos() {
  const { ref: revealRef, visible } = useReveal<HTMLDivElement>();
  const { ref: barsRef, filled } = usePerformanceBars<HTMLDivElement>();
  // Both hooks observe the same node, so a callback ref assigns it to both.
  const setVisualRef = (node: HTMLDivElement | null) => {
    revealRef.current = node;
    barsRef.current = node;
  };

  return (
    <section className="porque">
      <div className="container">
        <div className="porque-grid">
          <Reveal>
            <Eyebrow>Nosso diferencial</Eyebrow>
            <h2 className="section-title">
              Por que escolher a
              <br />
              Prime Sites Brasil?
            </h2>
            <div className="porque-list">
              {porqueItems.map((item) => (
                <div className="porque-item" key={item.title}>
                  <div className="porque-icon">{item.icon}</div>
                  <div>
                    <div className="porque-title">{item.title}</div>
                    <div className="porque-text">{item.text}</div>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>

          <div
            ref={setVisualRef}
            className={`reveal d2 porque-visual${visible ? ' visible' : ''}`}
          >
            <div className="pv-title">Não é só bonito. É medido.</div>
            <div className="pv-sub">Média dos últimos projetos entregues</div>
            {performanceMetrics.map((metric) => (
              <div className="pv-metric" key={metric.label}>
                <div className="pv-row">
                  <span className="pv-label">{metric.label}</span>
                  <span className="pv-val">{metric.value}</span>
                </div>
                <div className="pv-bar-wrap">
                  <div
                    className={`pv-bar${filled ? ' filled' : ''}`}
                    style={{ ['--w' as any]: `${metric.width}%` }}
                  />
                </div>
              </div>
            ))}
            <div className="pv-foot">Medido com Google Lighthouse</div>
          </div>
        </div>
      </div>
    </section>
  );
}
