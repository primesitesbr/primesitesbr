'use client';

import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { useMagnetic } from '@/hooks/useMagnetic';
import { waLink } from '@/lib/constants';

export default function Closing() {
  const ctaRef = useMagnetic<HTMLAnchorElement>();

  return (
    <section className="closing">
      <div className="container">
        <Eyebrow gold center>
          Último passo
        </Eyebrow>
        <Reveal onDark as="div">
          <h2 className="closing-title">Bora colocar seu negócio no ar essa semana?</h2>
        </Reveal>
        <a
          ref={ctaRef}
          href={waLink('Olá! Vim pelo site e quero solicitar um orçamento.')}
          className="btn-primary"
          data-magnetic
          target="_blank"
          rel="noopener noreferrer"
        >
          💬 Quero começar agora
        </a>
        <p className="closing-fine">Sem compromisso · Orçamento gratuito · Resposta em até 24h</p>
      </div>
    </section>
  );
}
