'use client';

import { useState } from 'react';
import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { faqItems } from '@/lib/data';

export default function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="faq" id="faq">
      <div className="container">
        <Reveal className="faq-header">
          <Eyebrow>Dúvidas frequentes</Eyebrow>
          <h2 className="section-title">FAQ</h2>
        </Reveal>
        <Reveal delay={1} className="faq-list">
          {faqItems.map((item, i) => {
            const open = openIndex === i;
            return (
              <div className={`faq-item${open ? ' open' : ''}`} key={item.question}>
                <button
                  type="button"
                  className="faq-q"
                  onClick={() => setOpenIndex(open ? null : i)}
                  aria-expanded={open}
                >
                  {item.question} <span className="faq-icon">+</span>
                </button>
                <div className="faq-a">{item.answer}</div>
              </div>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
