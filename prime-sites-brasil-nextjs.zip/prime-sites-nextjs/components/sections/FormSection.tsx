'use client';

import { FormEvent, useState } from 'react';
import Reveal from '@/components/ui/Reveal';
import Eyebrow from '@/components/ui/Eyebrow';
import { formFeatures, businessSegments, currentSiteOptions } from '@/lib/data';
import { waLink } from '@/lib/constants';

export default function FormSection() {
  const [error, setError] = useState<string | null>(null);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const nome = (form.elements.namedItem('nome') as HTMLInputElement).value.trim();
    const whatsapp = (form.elements.namedItem('whatsapp') as HTMLInputElement).value.trim();

    if (!nome || !whatsapp) {
      setError('Por favor, preencha pelo menos seu nome e WhatsApp.');
      return;
    }
    setError(null);
    window.open(
      waLink(`Olá! Me chamo ${nome} e gostaria de solicitar um orçamento de site.`),
      '_blank'
    );
  }

  return (
    <section className="form-section noise" id="orcamento">
      <div className="container">
        <Reveal onDark>
          <Eyebrow gold>Solicitar orçamento</Eyebrow>
          <h2 className="section-title">Vamos conversar?</h2>
        </Reveal>
        <div className="form-grid">
          <Reveal onDark>
            <p className="section-sub">
              Preencha o formulário ou chame a gente direto no WhatsApp. Você recebe uma
              proposta personalizada em até 24h.
            </p>
            <div className="form-features">
              {formFeatures.map((feat) => (
                <div className="form-feat" key={feat.label}>
                  <div className="form-feat-icon">{feat.icon}</div>
                  {feat.label}
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal onDark delay={2}>
            <form className="form-box" onSubmit={handleSubmit} noValidate>
              <div className="form-row">
                <label className="form-label" htmlFor="nome">
                  Seu nome
                </label>
                <input
                  id="nome"
                  name="nome"
                  type="text"
                  className="form-input"
                  placeholder="Como podemos te chamar?"
                />
              </div>
              <div className="form-row">
                <label className="form-label" htmlFor="whatsapp">
                  WhatsApp
                </label>
                <input
                  id="whatsapp"
                  name="whatsapp"
                  type="tel"
                  className="form-input"
                  placeholder="(00) 00000-0000"
                />
              </div>
              <div className="form-row">
                <label className="form-label" htmlFor="segmento">
                  Segmento do negócio
                </label>
                <select id="segmento" name="segmento" className="form-select" defaultValue="">
                  <option value="">Selecione seu segmento</option>
                  {businessSegments.map((seg) => (
                    <option key={seg}>{seg}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <label className="form-label" htmlFor="siteAtual">
                  Tem site atualmente?
                </label>
                <select id="siteAtual" name="siteAtual" className="form-select">
                  {currentSiteOptions.map((opt) => (
                    <option key={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <label className="form-label" htmlFor="observacao">
                  Alguma observação? (opcional)
                </label>
                <textarea
                  id="observacao"
                  name="observacao"
                  className="form-textarea"
                  placeholder="Conte um pouco sobre o seu projeto..."
                />
              </div>
              {error && (
                <p style={{ color: '#E3C179', fontSize: 13, marginBottom: 16 }} role="alert">
                  {error}
                </p>
              )}
              <button type="submit" className="form-submit">
                📨 Solicitar orçamento agora
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
