import { Fragment } from 'react';
import { tickerItems } from '@/lib/data';

export default function Ticker() {
  // Duplicated once so the CSS animation can loop seamlessly at -50%.
  const loop = [...tickerItems, ...tickerItems];

  return (
    <div className="ticker-band">
      <span className="ticker-label">Já criamos sites para</span>
      <div className="ticker-viewport">
        <div className="ticker-track">
          {loop.map((item, i) => (
            <Fragment key={`${item}-${i}`}>
              <span>{item}</span>
              <span>·</span>
            </Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
