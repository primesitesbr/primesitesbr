'use client';

import { useEffect, useRef } from 'react';

/** Pointer-drag before/after comparison, ported 1:1 from the original
 * pointerdown/pointermove logic so touch and mouse behave identically. */
export default function CompareSlider() {
  const stageRef = useRef<HTMLDivElement>(null);
  const afterRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stage = stageRef.current;
    const afterPanel = afterRef.current;
    const handle = handleRef.current;
    if (!stage || !afterPanel || !handle) return;

    let dragging = false;

    const setPct = (pct: number) => {
      pct = Math.max(0, Math.min(100, pct));
      afterPanel.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
      handle.style.left = `${pct}%`;
    };

    const pctFromEvent = (clientX: number) => {
      const rect = stage.getBoundingClientRect();
      return ((clientX - rect.left) / rect.width) * 100;
    };

    const onPointerDown = (e: PointerEvent) => {
      dragging = true;
      stage.setPointerCapture(e.pointerId);
      setPct(pctFromEvent(e.clientX));
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!dragging) return;
      setPct(pctFromEvent(e.clientX));
    };
    const onPointerUp = (e: PointerEvent) => {
      dragging = false;
      try {
        stage.releasePointerCapture(e.pointerId);
      } catch {
        // no-op: capture may already be released
      }
    };
    const onPointerCancel = () => {
      dragging = false;
    };

    stage.addEventListener('pointerdown', onPointerDown);
    stage.addEventListener('pointermove', onPointerMove);
    stage.addEventListener('pointerup', onPointerUp);
    stage.addEventListener('pointercancel', onPointerCancel);

    setPct(50);

    return () => {
      stage.removeEventListener('pointerdown', onPointerDown);
      stage.removeEventListener('pointermove', onPointerMove);
      stage.removeEventListener('pointerup', onPointerUp);
      stage.removeEventListener('pointercancel', onPointerCancel);
    };
  }, []);

  return (
    <div className="compare-wrap">
      <div className="compare-browser">
        <div className="compare-bar">
          <div className="compare-dot cd1" />
          <div className="compare-dot cd2" />
          <div className="compare-dot cd3" />
          <div className="compare-url">seunegocio.com.br</div>
        </div>
        <div className="compare-stage" ref={stageRef}>
          <div className="compare-panel compare-before">
            <div className="old-hd">
              <div className="old-logo" />
              <div className="old-menu">
                <div className="old-mi" />
                <div className="old-mi" />
                <div className="old-mi" />
              </div>
            </div>
            <div className="old-body">
              <div className="old-hero" />
              <div className="old-hero2" />
              <div className="old-rows">
                <div className="old-row" />
                <div className="old-row" style={{ width: '70%' }} />
                <div className="old-row" style={{ width: '55%' }} />
              </div>
            </div>
            <div className="old-tag">só Instagram</div>
          </div>
          <div className="compare-panel compare-after" ref={afterRef}>
            <div className="new-hd">
              <div className="new-logo">
                Prime<span>Sites</span>
              </div>
              <div className="new-menu">
                <div className="new-mi" />
                <div className="new-mi" />
                <div className="new-mi" />
              </div>
              <div className="new-cta">Contato</div>
            </div>
            <div className="new-body">
              <div className="new-h" />
              <div className="new-s" />
              <div className="new-b" />
              <div className="new-cards">
                <div className="new-card" />
                <div className="new-card" />
                <div className="new-card" />
              </div>
            </div>
          </div>
          <div className="compare-handle" ref={handleRef}>
            <div className="compare-grip">↔</div>
          </div>
        </div>
        <div className="compare-float">
          <div className="cf-label">PageSpeed</div>
          <div className="cf-value">98</div>
          <div className="cf-sub">🟢 desempenho excelente</div>
        </div>
      </div>
      <div className="compare-legend">
        <div className="compare-tags">
          <span className="compare-tag compare-tag-before">Antes</span>
          <span className="compare-tag compare-tag-after">Depois</span>
        </div>
        <span className="compare-hint">Arraste para comparar</span>
      </div>
    </div>
  );
}
