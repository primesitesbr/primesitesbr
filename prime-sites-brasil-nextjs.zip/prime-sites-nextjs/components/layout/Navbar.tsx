'use client';

import Link from 'next/link';
import { useNavScroll } from '@/hooks/useNavScroll';
import { useMagnetic } from '@/hooks/useMagnetic';
import { navLinks } from '@/lib/data';
import { waLink } from '@/lib/constants';

export default function Navbar() {
  const scrolled = useNavScroll();
  const ctaRef = useMagnetic<HTMLAnchorElement>();

  return (
    <nav id="navbar" className={scrolled ? 'scrolled' : ''}>
      <div className="container">
        <div className="nav-inner">
          <Link href="#top" className="nav-logo">
            Prime Sites<span className="tag">BR</span>
          </Link>
          <ul className="nav-links">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href}>{link.label}</Link>
              </li>
            ))}
          </ul>
          <a
            ref={ctaRef}
            href={waLink('Olá! Quero solicitar um orçamento de site.')}
            className="nav-cta"
            data-magnetic
            target="_blank"
            rel="noopener noreferrer"
          >
            Solicitar orçamento
          </a>
        </div>
      </div>
    </nav>
  );
}
