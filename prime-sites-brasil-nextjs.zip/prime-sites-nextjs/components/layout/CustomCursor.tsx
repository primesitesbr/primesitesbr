'use client';

import { useEffect, useRef } from 'react';

/** Desktop-only custom cursor (dot + trailing ring) that grows when
 * hovering interactive elements. Skipped on touch devices and when
 * prefers-reduced-motion is set, matching the original script. */
export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const isFine = window.matchMedia('(pointer:fine)').matches;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!isFine || reduced) return;

    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    document.body.classList.add('has-custom-cursor');

    let mx = 0,
      my = 0,
      rx = 0,
      ry = 0,
      shown = false;
    let raf = 0;

    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      dot.style.transform = `translate(${mx}px,${my}px)`;
      if (!shown) {
        dot.classList.add('active');
        ring.classList.add('active');
        shown = true;
      }
    };

    const loop = () => {
      rx += (mx - rx) * 0.18;
      ry += (my - ry) * 0.18;
      ring.style.transform = `translate(${rx}px,${ry}px)`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const hoverables = 'a, button, input, select, textarea, [data-magnetic], .faq-q';
    const onOver = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest(hoverables)) ring.classList.add('hovering');
    };
    const onOut = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest(hoverables)) ring.classList.remove('hovering');
    };

    window.addEventListener('mousemove', onMove);
    document.addEventListener('mouseover', onOver);
    document.addEventListener('mouseout', onOut);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseover', onOver);
      document.removeEventListener('mouseout', onOut);
      document.body.classList.remove('has-custom-cursor');
    };
  }, []);

  return (
    <>
      <div className="cursor-dot" ref={dotRef} />
      <div className="cursor-ring" ref={ringRef} />
    </>
  );
}
