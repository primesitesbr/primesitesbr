import Link from 'next/link';
import { SITE } from '@/lib/constants';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer>
      <div className="container">
        <div className="footer-inner">
          <div>
            <div className="footer-logo">
              Prime Sites<span> Brasil</span>
            </div>
            <p className="footer-tagline">
              Sites modernos e feitos sob medida para pequenas e médias empresas de todo o
              Brasil.
            </p>
          </div>
          <div>
            <div className="footer-col-title">Navegação</div>
            <div className="footer-links">
              <Link href="#solucao">O que entregamos</Link>
              <Link href="#portfolio">Portfólio</Link>
              <Link href="#como-funciona">Como funciona</Link>
              <Link href="#faq">FAQ</Link>
              <Link href="#orcamento">Solicitar orçamento</Link>
            </div>
          </div>
          <div>
            <div className="footer-col-title">Contato</div>
            <div className="footer-links">
              <a
                href={`https://wa.me/${SITE.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                💬 WhatsApp
              </a>
              <a href={SITE.instagram} target="_blank" rel="noopener noreferrer">
                📷 Instagram
              </a>
              <a href={`mailto:${SITE.email}`}>✉️ E-mail</a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="footer-copy">© {year} Prime Sites Brasil. Todos os direitos reservados.</div>
          <div className="footer-cnpj">CNPJ: {SITE.cnpj}</div>
        </div>
      </div>
    </footer>
  );
}
