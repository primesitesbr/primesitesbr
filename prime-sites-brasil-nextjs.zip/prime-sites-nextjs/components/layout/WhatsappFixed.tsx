'use client';

import { useMagnetic } from '@/hooks/useMagnetic';
import { waLink } from '@/lib/constants';

export default function WhatsappFixed() {
  const ref = useMagnetic<HTMLAnchorElement>();

  return (
    <a
      ref={ref}
      href={waLink('Olá! Quero solicitar um orçamento.')}
      className="wa-fixed"
      title="Falar no WhatsApp"
      data-magnetic
      target="_blank"
      rel="noopener noreferrer"
    >
      💬
    </a>
  );
}
