# Prime Sites Brasil — Next.js 15 + TypeScript + Tailwind

Conversão pixel-perfect da landing page estática (`prime-sites-brasil.html`) para uma
aplicação Next.js 15 (App Router) em TypeScript, pronta para deploy na Vercel.

## Stack

- **Next.js 15** (App Router, React Server Components onde possível)
- **TypeScript** em modo estrito
- **Tailwind CSS** para tokens/utilitários + CSS global para os componentes visuais
  mais complexos (o design original é muito específico — hero com comparador
  drag, ticker infinito, cursor customizado etc. — então essas classes foram
  portadas 1:1 em `app/globals.css` para garantir fidelidade pixel a pixel)
- `next/font/google` para Fraunces, Plus Jakarta Sans e IBM Plex Mono (sem FOUT,
  sem chamadas externas ao Google Fonts em runtime)

## Estrutura de pastas

```
app/
  layout.tsx        # fontes, <head> e metadata SEO globais
  page.tsx           # monta as seções na ordem da página
  globals.css         # tokens (CSS vars) + estilos de cada seção
  sitemap.ts          # /sitemap.xml dinâmico
  robots.ts           # /robots.txt dinâmico
components/
  layout/             # Navbar, Footer, CustomCursor, WhatsappFixed
  sections/            # Hero, CompareSlider, Ticker, Problema, Solucao,
                        # ComoFunciona, PorQueNos, Portfolio, Depoimentos,
                        # Faq, FormSection, Closing
  ui/                  # Reveal (scroll-reveal genérico), Eyebrow
hooks/
  useNavScroll.ts       # estado "scrolled" da navbar
  useReveal.ts           # IntersectionObserver do scroll-reveal
  useMagnetic.ts          # efeito magnético dos botões (desktop only)
  usePerformanceBars.ts    # preenchimento das barras de métricas
lib/
  data.ts                # todo o conteúdo textual do site, tipado
  constants.ts             # WhatsApp, e-mail, Instagram, CNPJ centralizados
types/
  index.ts                  # tipos compartilhados do conteúdo
```

## Comportamentos preservados

- Comparador "antes/depois" arrastável (pointer events, funciona em touch e mouse)
- Cursor customizado (dot + ring com easing), desativado em touch e
  `prefers-reduced-motion`
- Botões "magnéticos" que seguem o mouse
- Ticker infinito em CSS puro (`@keyframes`)
- Scroll-reveal com `IntersectionObserver`, com fallback visível por padrão
  (progressive enhancement, igual ao script original)
- Barras de performance que preenchem ao entrar na viewport
- Accordion do FAQ controlado por estado React (um item aberto por vez)
- Formulário de orçamento que valida nome/WhatsApp e abre o WhatsApp Web/App
  com a mensagem pré-preenchida
- `@media (prefers-reduced-motion: reduce)` respeitado globalmente

## Editar conteúdo

Quase todo o texto do site (estatísticas, pilares, timeline, portfólio,
depoimentos, FAQ) vive em `lib/data.ts` — edite os arrays lá em vez de mexer
nos componentes. Número de WhatsApp, e-mail, Instagram e CNPJ ficam em
`lib/constants.ts`.

## SEO

- `app/layout.tsx` define `title`, `description`, Open Graph e Twitter cards
- `app/sitemap.ts` e `app/robots.ts` geram `/sitemap.xml` e `/robots.txt`
  automaticamente
- HTML semântico (`<nav>`, `<main>`, `<section>`, `<footer>`, `<h1>`/`<h2>`)

## Imagens

O design original não usa nenhuma imagem raster — todos os "mockups" de
browser/site são construídos em CSS puro (divs com gradientes). Por isso não
há `<img>`/`next/image` no projeto ainda. `next.config.mjs` já está preparado
com `images.formats` e um exemplo comentado de `remotePatterns` para quando
você substituir os mockups do portfólio por screenshots reais — nesse caso,
troque os blocos `.pf-screen` por `<Image />` do `next/image`.

## Rodando localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000.

## Deploy na Vercel

```bash
npm run build
```

Depois é só importar o repositório na Vercel (ou rodar `vercel`/`vercel --prod`
com a CLI) — não é necessária nenhuma configuração adicional, o projeto usa
apenas as convenções padrão do App Router.
