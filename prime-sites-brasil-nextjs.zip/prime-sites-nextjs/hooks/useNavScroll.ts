'use client';

import { useEffect, useState } from 'react';

/** Tracks whether the page has scrolled past the threshold used to
 * switch the navbar into its compact, frosted "scrolled" state. */
export function useNavScroll(threshold = 40) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > threshold);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [threshold]);

  return scrolled;
}
