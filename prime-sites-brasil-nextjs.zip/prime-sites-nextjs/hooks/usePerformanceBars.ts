'use client';

import { useEffect, useRef, useState } from 'react';

/** Triggers the animated fill of the "Por que nós" metric bars once
 * the visual scrolls into view, mirroring the original barObs logic. */
export function usePerformanceBars<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T | null>(null);
  const [filled, setFilled] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) {
      setFilled(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setFilled(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.4 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return { ref, filled };
}
