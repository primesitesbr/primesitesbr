import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#070B14',
        navy: {
          950: '#060C1A',
          900: '#0A1630',
          800: '#0F2049',
          700: '#15305F',
        },
        blue: {
          DEFAULT: '#3E6FE0',
          soft: '#DCE6FB',
        },
        gold: {
          DEFAULT: '#B99451',
          hi: '#E3C179',
          pale: '#F7EFDD',
        },
        paper: {
          DEFAULT: '#F6F6F3',
          2: '#EDECE7',
        },
        body: {
          DEFAULT: '#2B303B',
          mute: '#666D7A',
          faint: '#9CA3AF',
        },
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'Georgia', 'serif'],
        body: ['var(--font-jakarta)', '-apple-system', 'sans-serif'],
        mono: ['var(--font-ibm-plex-mono)', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '10px',
        lg: '26px',
      },
      transitionTimingFunction: {
        brand: 'cubic-bezier(.16,1,.3,1)',
      },
      boxShadow: {
        soft: '0 1px 3px rgba(7,11,20,.07)',
        lift: '0 26px 54px -14px rgba(7,11,20,.20)',
        gold: '0 20px 42px -10px rgba(185,148,81,.38)',
      },
    },
  },
  plugins: [],
};

export default config;
