// Central place for contact details so a single edit updates every
// WhatsApp link, footer, and mailto across the site.
export const SITE = {
  name: 'Prime Sites Brasil',
  url: 'https://www.primesitesbrasil.com.br',
  description:
    'Sites profissionais para pequenas e médias empresas, prontos em até 7 dias. Design sob medida, SEO técnico, hospedagem inclusa.',
  whatsappNumber: '5500000000000',
  email: 'contato@primesitesbrasil.com.br',
  instagram: 'https://instagram.com/',
  cnpj: '00.000.000/0001-00',
};

export function waLink(message: string) {
  return `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
