import type {
  NavLink,
  HeroStat,
  ProblemaRow,
  Pillar,
  TimelineStep,
  PorQueItem,
  PerformanceMetric,
  PortfolioItem,
  Testimonial,
  FaqItem,
  FormFeature,
} from '@/types';

export const navLinks: NavLink[] = [
  { href: '#problema', label: 'Por que preciso?' },
  { href: '#portfolio', label: 'Portfólio' },
  { href: '#como-funciona', label: 'Como funciona' },
  { href: '#faq', label: 'FAQ' },
];

export const heroStats: HeroStat[] = [
  { num: '80+', label: 'Sites entregues' },
  { num: '98%', label: 'Clientes satisfeitos' },
  { num: '7d', label: 'Prazo médio' },
];

export const tickerItems: string[] = [
  'Eletricistas',
  'Nutricionistas',
  'Clínicas',
  'Restaurantes',
  'Advogados',
  'Lojas de materiais',
  'Salões de beleza',
  'Petshops',
];

export const problemaRows: ProblemaRow[] = [
  {
    icon: '📱',
    label: 'Só existe no Instagram',
    sub: 'Alcance limitado e passa sensação de negócio informal',
  },
  {
    icon: '🕸️',
    label: 'Site antigo, lento ou fora do ar',
    sub: 'O cliente sai antes mesmo de terminar de carregar',
  },
  {
    icon: '🔍',
    label: 'Invisível no Google',
    sub: 'Quem procura, simplesmente não te encontra',
  },
  {
    icon: '💸',
    label: 'Perde para quem parece mais profissional',
    sub: 'A confiança vai para o concorrente com melhor apresentação',
  },
];

export const pillars: Pillar[] = [
  {
    name: 'Design & identidade',
    title: 'Feito pra sua marca, não pra um template',
    items: [
      {
        icon: '🎨',
        title: 'Visual sob medida',
        text: 'Design pensado pro seu setor e seu público — não um modelo pronto com sua logo colada.',
      },
      {
        icon: '📱',
        title: '100% responsivo',
        text: 'Perfeito no celular, no tablet e no computador — onde seu cliente estiver.',
      },
      {
        icon: '🌐',
        title: 'Domínio próprio incluso',
        text: 'Seu .com.br registrado e configurado, sem custo separado.',
      },
    ],
  },
  {
    name: 'Performance & confiança',
    title: 'Rápido, seguro e sempre no ar',
    items: [
      {
        icon: '⚡',
        title: 'Velocidade real',
        text: 'Nota acima de 90 no Google PageSpeed. Ninguém espera site carregar.',
      },
      {
        icon: '☁️',
        title: 'Hospedagem inclusa',
        text: 'Servidor rápido e estável, sem custo extra no primeiro ano.',
      },
      {
        icon: '🔒',
        title: 'HTTPS e segurança',
        text: 'Certificado de segurança configurado desde o primeiro dia.',
      },
    ],
  },
  {
    name: 'Geração de clientes',
    title: 'Pensado para virar contato',
    items: [
      {
        icon: '🔍',
        title: 'SEO técnico configurado',
        text: 'Estrutura pronta pra aparecer no Google — o orgânico cresce com o tempo.',
      },
      {
        icon: '💬',
        title: 'Botão de WhatsApp fixo',
        text: 'Um clique separa o visitante de virar conversa.',
      },
      {
        icon: '📍',
        title: 'Formulário + Google Maps',
        text: 'Capture contato e mostre onde te encontrar, direto na página.',
      },
    ],
  },
];

export const timelineSteps: TimelineStep[] = [
  {
    num: '01',
    icon: '💬',
    title: 'Conversamos',
    text: 'Você conta sobre o negócio, o público e o que precisa. Rápido, sem compromisso.',
  },
  {
    num: '02',
    icon: '🎨',
    title: 'Criamos o layout',
    text: 'Montamos um design sob medida pra sua marca — não um template com a logo trocada.',
  },
  {
    num: '03',
    icon: '✅',
    title: 'Você aprova',
    text: 'Revisamos juntos até ficar do jeito certo. Ajustes inclusos nessa etapa.',
  },
  {
    num: '04',
    icon: '🚀',
    title: 'Publicamos',
    text: 'Site no ar com domínio, hospedagem e suporte, prontos pra gerar contato.',
  },
];

export const porqueItems: PorQueItem[] = [
  {
    icon: '⚡',
    title: 'Entrega rápida, sem enrolação',
    text: 'A maioria dos projetos fica pronta em até 7 dias úteis. Você não fica esperando meses.',
  },
  {
    icon: '🎯',
    title: 'Focado em conversão',
    text: 'Não fazemos site bonito por fazer. Cada elemento é pensado pra gerar contato e venda.',
  },
  {
    icon: '🤝',
    title: 'Atendimento direto e ágil',
    text: 'Você fala com quem faz. Sem terceiros, sem demora, sem burocracia.',
  },
  {
    icon: '💰',
    title: 'Preço justo, resultado real',
    text: 'Sites profissionais acessíveis pra pequenas e médias empresas crescerem.',
  },
];

export const performanceMetrics: PerformanceMetric[] = [
  { label: 'Velocidade (PageSpeed)', value: '96 / 100', width: 96 },
  { label: 'Responsividade mobile', value: '100%', width: 100 },
  { label: 'Score de acessibilidade', value: '92 / 100', width: 92 },
  { label: 'SEO técnico', value: '95 / 100', width: 95 },
];

export const portfolioItems: PortfolioItem[] = [
  {
    featured: true,
    segment: 'Advocacia',
    name: 'Escritório Jurídico Exemplo',
    description:
      'Site institucional para transmitir autoridade e confiança — com blog para SEO e formulário de consulta direto na página.',
    tags: ['Institucional', 'SEO', 'Blog'],
    href: 'Quero um site como o de Advocacia',
    mockGradient: 'linear-gradient(135deg,#1A3A6B,#0D1E40)',
    accentColor: '#3E6FE0',
    barBg: '#050D1A',
  },
  {
    segment: 'Clínica de saúde',
    name: 'Clínica Bem Estar',
    tags: ['Agendamento', 'WhatsApp', 'Maps'],
    href: 'Quero um site como o de Clínica',
    mockGradient: 'linear-gradient(135deg,#1A4020,#0D2010)',
    accentColor: '#22C55E',
    barBg: '#050F05',
  },
  {
    segment: 'Restaurante',
    name: 'Sabores do Chef',
    tags: ['Cardápio digital', 'Delivery', 'Maps'],
    href: 'Quero um site como o de Restaurante',
    mockGradient: 'linear-gradient(135deg,#4A2010,#2A1008)',
    accentColor: '#B99451',
    barBg: '#0D0604',
  },
];

export const testimonials: Testimonial[] = [
  {
    quote:
      'Depois do site recebemos muito mais contatos. Em 30 dias já tínhamos recuperado o investimento. Recomendo sem hesitar.',
    name: 'Marcos Ferreira',
    business: 'Eletricista — MF Elétrica',
    chip: 'Investimento recuperado em 30 dias',
    initials: 'MF',
  },
  {
    quote:
      'Antes eu só tinha Instagram e perdia muito cliente. Agora apareço no Google quando alguém pesquisa na minha cidade.',
    name: 'Ana Paula Ramos',
    business: 'Nutricionista',
    chip: 'Agora aparece no Google da cidade',
    initials: 'AP',
  },
  {
    quote:
      'Atendimento rápido, site bonito e funcional. Entregaram antes do prazo e ainda me ensinaram a usar. Nota 10.',
    name: 'Roberto Campos',
    business: 'Loja de materiais de construção',
    chip: 'Entregue antes do prazo',
    initials: 'RC',
  },
];

export const faqItems: FaqItem[] = [
  {
    question: 'Quanto tempo leva para ficar pronto?',
    answer:
      'A maioria dos projetos fica pronta em 5 a 7 dias úteis após a aprovação do briefing e pagamento. Projetos com conteúdo mais extenso podem levar até 14 dias.',
  },
  {
    question: 'Preciso entender de tecnologia?',
    answer:
      'Não. A gente cuida de tudo — hospedagem, domínio, publicação e configuração. Você só precisa contar sobre o seu negócio.',
  },
  {
    question: 'Quanto custa um site?',
    answer:
      'O valor varia conforme a complexidade e o número de páginas. Fale com a gente pra um orçamento sem compromisso — respondemos em menos de 24h.',
  },
  {
    question: 'Posso pedir alterações depois?',
    answer:
      'Sim. Durante o desenvolvimento você tem rodadas de revisão incluídas. Depois da entrega, também oferecemos planos de manutenção mensal.',
  },
  {
    question: 'O site vai aparecer no Google?',
    answer:
      'Todo site sai com SEO técnico configurado — meta tags, sitemap, velocidade otimizada e indexação no Search Console. O orgânico cresce com o tempo, mas a base já vai pronta.',
  },
  {
    question: 'Hospedam fora do Brasil?',
    answer:
      'Não. Usamos servidor no Brasil pra garantir velocidade máxima pro público daqui. A hospedagem já vem inclusa no primeiro ano.',
  },
];

export const formFeatures: FormFeature[] = [
  { icon: '💬', label: 'Orçamento sem compromisso' },
  { icon: '⚡', label: 'Resposta em até 24h' },
  { icon: '🎯', label: 'Proposta pensada pro seu negócio' },
  { icon: '🔒', label: 'Seus dados ficam só entre a gente' },
];

export const businessSegments = [
  'Saúde / Clínica',
  'Advocacia / Consultoria',
  'Restaurante / Alimentação',
  'Comércio / Loja',
  'Serviços gerais',
  'Outro',
];

export const currentSiteOptions = [
  'Não tenho site',
  'Tenho site antigo',
  'Só tenho Instagram',
];
