/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Add real remote hosts here when portfolio screenshots / photos
    // are swapped in for the current CSS mockups, e.g.:
    // remotePatterns: [{ protocol: 'https', hostname: 'cdn.primesitesbrasil.com.br' }],
    formats: ['image/avif', 'image/webp'],
  },
  compress: true,
};

export default nextConfig;
