import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import WhatsappFixed from '@/components/layout/WhatsappFixed';
import Hero from '@/components/sections/Hero';
import Ticker from '@/components/sections/Ticker';
import Problema from '@/components/sections/Problema';
import Solucao from '@/components/sections/Solucao';
import ComoFunciona from '@/components/sections/ComoFunciona';
import PorQueNos from '@/components/sections/PorQueNos';
import Portfolio from '@/components/sections/Portfolio';
import Depoimentos from '@/components/sections/Depoimentos';
import Faq from '@/components/sections/Faq';
import FormSection from '@/components/sections/FormSection';
import Closing from '@/components/sections/Closing';

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Ticker />
        <Problema />
        <Solucao />
        <ComoFunciona />
        <PorQueNos />
        <Portfolio />
        <Depoimentos />
        <Faq />
        <FormSection />
        <Closing />
      </main>
      <Footer />
      <WhatsappFixed />
    </>
  );
}
